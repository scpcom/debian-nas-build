#!/bin/sh
# ============================================================================
#
# This file is part of the 'Univeral usb_key_func.sh stick'
# http://zyxel.nas-central.org/wiki/Usb_key_func.sh#.27Universal_stick.27
#
# This program is free software; you can redistribute it and/or modify it 
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 2, or (at your option) any
# later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# Author: Mijzelf <Mijzelf@live.com>
#
# ============================================================================
# 
# If you change anything in this file, you'll have to recreate the 
# salted_md5sum file
#

exec ${0}.2
