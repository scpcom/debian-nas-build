#!/bin/sh

cd `dirname $0`

sudo apt-get install -y i2c-tools mtd-utils

sudo dpkg -i linux-bsp-*_*_*.deb

cd - > /dev/null

